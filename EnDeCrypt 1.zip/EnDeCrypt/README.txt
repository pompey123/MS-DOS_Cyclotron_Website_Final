TO RUN
``````
First read through the info below and follow the steps. Then click "enDeCrypt.exe". 

It will not work unless you follow the steps below and read the information. I have not made it self-explanatory because it is designed for people with brain cells, so you will need to read all the instructions here, and in-program too. 

This is for Windows users specifically. If you are on MacOS or Linux your computer may behave differently.

Programs need a £400 security certificate in order to run with no questions asked. Because I am broke, you will have to remove the "from the internet" mark yourself. Interestingly enough, on Windows, you can do this as a normal user or an administrator, which is a questionable design choice, but I have no bearing over crazy Windows boffins, so this step takes almost no effort:

[1] Right-click file.
[2] Select "Properties".
[3] Navigate to the "General" tab.
[4] Click "Unblock".
[5] Click "Apply".
[6] Click "OK".
[7] Repeat for each file in turn.

Note: if you do not see this option, that just means that the file has been unblocked already, for whatever reason.

IMPORTANT
`````````
If you still have qualms about this program, its open source. If you have a compiler, you can recompile it if you want. You can read through the source-code. It is 100% safe.

If the program shows information, read it, then press enter. If it asks you to type something, type it, then press enter.