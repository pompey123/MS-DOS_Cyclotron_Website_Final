#include<iostream>
#include<algorithm>
#include<numeric>
#include<fstream>
#include<iterator>
#include<string>
#include<random>
#include<vector>
#include<cstdlib>
using namespace std;

string stringToUpper(string text)
{
    for(char& i: text)
    {
        i = toupper(i);
    }

    return text;
}

void cls()
{
    int option;

    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

void encrypt(int option, string &key, string &plainText, string &cipherText)
{
    string ignore;
    string file;
    random_device seed;
    mt19937 random(seed());
    uniform_int_distribution<> railFence(5, 9);
    uniform_int_distribution<> viginere(65, 90);
    uniform_int_distribution<> permutationLength(5, 9);

    key = to_string(railFence(random));
    for(int i = 1; i <= 6; i++)
    {
        key += (static_cast<char> (viginere(random)));
    }
    key += to_string(permutationLength(random));

    vector<int> permutation(stoi(key.substr(7, 1)));
    iota(permutation.begin(), permutation.end(), 1);
    shuffle(permutation.begin(), permutation.end(), random);
    for(int i : permutation)
    {
        key += to_string(i);
    }

    cls();
    if(option == 0)
    {
        cout<<endl<<"PLAINTEXT: "<<endl<<endl;
        getline(cin, plainText);
    }
    else if(option == 1)
    {
        ifstream input("input.txt");
        if(!input)
        {
            cerr<<endl<<endl<<"COULD NOT OPEN \"input.txt\"."<<endl<<endl;
            return;
        }
        else
        {
            plainText.assign(istreambuf_iterator<char>(input), istreambuf_iterator<char>());
            for(unsigned char i : plainText)
            {
                if(i>127)
                {
                    cerr<<"ASCII ONLY."<<endl;
                    return;
                }
            }
        }
    }
    else if(option == 2)
    {
        cout<<endl<<"FILE (WITH FILE EXTENSION): "<<endl<<endl;
        getline(cin, file);
        ifstream input(file, ios::binary);
        if(!input)
        {
            cerr<<endl<<endl<<"COULD NOT OPEN \""<<file<<"\"."<<endl<<endl;
            return;
        }
        else
        {
            plainText.assign(istreambuf_iterator<char>(input), istreambuf_iterator<char>());
        }
    }

    auto encrypt = [&plainText, &cipherText, &key, option]()
    {
        int railFenceKey;
        string viginereKey;
        int permutationKeyLen;
        vector<int> permutationKey;

        auto keys = [key, &railFenceKey, &viginereKey, &permutationKey, &permutationKeyLen]()
        {
            railFenceKey = stoi(key.substr(0, 1));
            viginereKey = key.substr(1, 6);
            permutationKeyLen = stoi(key.substr(7, 1));
            for(char i : key.substr(8, permutationKeyLen))
            {
                permutationKey.push_back(stoi(string(1, i)));
            }
        };
        keys();
        auto railFence = [&plainText, &cipherText, &key, railFenceKey]()
        {
            int diags;
            int diagNum;

            int padding = 0;
            while(((plainText.size()-1)%(railFenceKey-1)) != 0)
            {
                plainText += " ";
                padding++;
            }
            key += to_string(padding);

            diags = 2*(railFenceKey-1);
            diagNum = (plainText.size()-1)/(railFenceKey-1);

            for(int i = 0; i<plainText.size(); i+=diags)
            {
                cipherText += plainText[i];
            }

            bool switcher = false;
            int counter = 0;
            int index = 1;
            int rowNum = 1;
            int switched = 0;
            int unswitched = 0;
            for(int i = 1; i<=diagNum*(railFenceKey-2); i++)
            {
                if(counter >= diagNum)
                {
                    rowNum++;
                    counter = 0;
                    index = rowNum;
                    switcher = false;
                }
                switched = rowNum*2;
                unswitched = diags-switched;
                cipherText += plainText[index];
                counter++;
                if(switcher)
                {
                    index += switched;
                    switcher = false;
                }
                else
                {
                    index += unswitched;
                    switcher = true;
                }
            }

            for(int i = railFenceKey-1; i<plainText.size(); i+=diags)
            {
                cipherText += plainText[i];
            }
        };
        auto viginere = [&plainText, &cipherText, viginereKey, option]()
        {
            if(option != 2)
            {
                string cleanText = "";
                for(char i : plainText)
                {
                    if(i == '\n')
                    {
                        cleanText += i;
                    }
                    else if(i < 32 || i > 126)
                    {

                    }
                    else
                    {
                        cleanText += i;
                    }
                }
                plainText = cleanText;
            }

            plainText = cipherText;
            cipherText = "";

            int counter = 0;
            for(char& i : plainText)
            {
                if(option != 2)
                {
                    if(i == '\n')
                    {
                        continue;
                    }
                }
                //usi = UnSigned I
                unsigned char usi = i;
                if(option != 2)
                {
                    usi = 32+(((usi+viginereKey[counter%viginereKey.size()])-32)%95);
                }
                else
                {
                    usi = (((usi+viginereKey[counter%viginereKey.size()]))%256);
                }
                i = usi;
                counter++;
            }
            cipherText = plainText;
        };
        auto permutation = [&plainText, &cipherText, &key, permutationKey, permutationKeyLen]()
        {
            plainText = cipherText;
            cipherText = "";
            string section = "";
            int padding = 0;

            while(plainText.size() % permutationKeyLen != 0)
            {
                plainText += " ";
                padding++;
            }
            key += to_string(padding);

            for(int i=0; i<plainText.size()/permutationKeyLen; i++)
            {
                for(int j = 0; j<permutationKeyLen; j++)
                {
                    section += plainText[permutationKeyLen*i +j];
                }
                for(int j = 0; j<permutationKeyLen; j++)
                {
                    cipherText += section[permutationKey[j]-1];
                }
                section = "";
            }
        };

        railFence();
        viginere();
        permutation();
    };
    encrypt();
    if(option == 0)
    {
        cout<<endl<<endl<<"ENCRYPTION KEY: \n\n"<<key<<endl<<endl<<"CIPHERTEXT: \n\n"<<"\""<<cipherText<<"\"";
    }
    else if (option ==1)
    {
        ofstream output("output.txt");
        if(!output)
        {
            cerr<<endl<<endl<<"COULD NOT OPEN \"output.txt\"."<<endl<<endl;
            return;
        }
        else
        {
            output<<"\""<<cipherText<<"\"";
        }
        cout<<endl<<"ENCRYPTION KEY: \n\n"<<key<<endl<<endl<<endl<<"CIPHERTEXT IS IN \"output.txt\"."<<endl;
    }
    else if(option == 2)
    {
        ofstream output(file, ios::binary);
        if(!output)
        {
            cerr<<endl<<endl<<"COULD NOT OPEN \""<<file<<"\"."<<endl<<endl;
            return;
        }
        else
        {
            cipherText = "\"" + cipherText + "\"";
            output.write(cipherText.data(), cipherText.size());
        }
        cout<<endl<<"ENCRYPTION KEY: \n\n"<<key<<endl<<endl<<endl<<"CIPHERTEXT IS IN \""<<file<<"\"."<<endl;
    }
    getline(cin, ignore);
}

void decrypt(int option, string &key, string &plainText, string &cipherText)
{
    string ignore;
    string file;

    cls();
    cout<<endl<<"ENCRYPTION KEY: "<<endl<<endl;
    cin>>key;
    cin.ignore(256, '\n');
    if(option == 0)
    {
        cout<<endl<<"CIPHERTEXT: "<<endl<<endl;
        getline(cin, cipherText);
    }
    else if(option == 1)
    {
        ifstream input("input.txt");
        if(!input)
        {
            cerr<<endl<<endl<<"COULD NOT OPEN \"input.txt\"."<<endl<<endl;
            return;
        }
        else
        {
            cipherText.assign(istreambuf_iterator<char>(input), istreambuf_iterator<char>());
            for(unsigned char i : cipherText)
            {
                if(i>127)
                {
                    cerr<<"ASCII ONLY."<<endl;
                    return;
                }
            }
        }
    }
    else if(option == 2)
    {
        cout<<endl<<"FILE (WITH FILE EXTENSION): "<<endl<<endl;
        getline(cin, file);
        ifstream input(file, ios::binary);
        if(!input)
        {
            cerr<<endl<<endl<<"COULD NOT OPEN \""<<file<<"\"."<<endl<<endl;
            return;
        }
        else
        {
            cipherText.assign(istreambuf_iterator<char>(input), istreambuf_iterator<char>());
        }
    }

    if(cipherText.size()>=2)
    {
        cipherText = cipherText.substr(1, cipherText.size()-2);
    }
    auto decrypt = [&plainText, &cipherText, key, option]()
    {
        int railFenceKey;
        string viginereKey;
        int permutationKeyLen;
        vector<int> permutationKey;

        auto keys = [key, &railFenceKey, &viginereKey, &permutationKey, &permutationKeyLen]()
        {
            railFenceKey = stoi(key.substr(0, 1));
            viginereKey = key.substr(1, 6);
            permutationKeyLen = stoi(key.substr(7, 1));
            for(char i : key.substr(8, permutationKeyLen))
            {
                permutationKey.push_back(stoi(string(1, i)));
            }
        };
        keys();
        auto railFence = [&plainText, &cipherText, key, railFenceKey]()
        {
            cipherText = plainText;
            plainText = "";

            int padding = stoi(key.substr(key.size()-2, 1));
            int top;
            int over;
            int bottom;
            int under;
            int diagNum;
            int counter = 0;
            int index = 0;
            int rowNum = 1;
            bool diagOdd = true;
            bool topSwitcher = false;
            bool bottomSwitcher = true;

            diagNum = (cipherText.size()-1)/(railFenceKey-1);
            if(diagNum %2 == 1)
            {
                over = (diagNum+1)/2;
            }
            else
            {
                over = (diagNum+2)/2;
            }
            top = over;
            bottom = diagNum;
            under = bottom-1;

            while(counter<cipherText.size())
            {
                plainText += cipherText[index];
                counter++;

                if(rowNum <= 1)
                {
                    index+=over;
                    over++;
                    rowNum++;
                    diagOdd = true;
                    bottomSwitcher = true;
                }
                else if(rowNum == 2 && topSwitcher)
                {
                    index-=top;
                    top++;
                    rowNum--;
                    topSwitcher = false;
                }
                else if(rowNum == railFenceKey-1 && bottomSwitcher)
                {
                    index+=bottom;
                    bottom--;
                    rowNum++;
                    bottomSwitcher = false;
                }
                else if(rowNum >= railFenceKey)
                {
                    index-=under;
                    under--;
                    rowNum--;
                    diagOdd = false;
                    topSwitcher = true;
                }
                else
                {
                    if(diagOdd)
                    {
                        index += diagNum;
                        rowNum++;
                    }
                    else
                    {
                        index -= diagNum;
                        rowNum--;
                    }
                }
            }
            plainText = plainText.substr(0, plainText.size()-padding);
        };
        auto viginere = [&plainText, &cipherText, viginereKey, option]()
        {
            cipherText = plainText;
            plainText = "";

            int counter = 0;
            for(char& i : cipherText)
            {
                if(option != 2)
                {
                    if(i == '\n')
                    {
                        continue;
                    }
                }
                //usi = UnSigned I
                unsigned char usi = i;
                if(option != 2)
                {
                    usi = ((usi-32-viginereKey[counter%viginereKey.size()]+95)%95)+32;
                }
                else
                {
                    usi = ((usi-viginereKey[counter%viginereKey.size()]+256)%256);
                }
                i = usi;
                counter++;
            }
            plainText = cipherText;
        };
        auto permutation = [&plainText, &cipherText, key, permutationKey, permutationKeyLen]()
        {
            string section = "";
            string ogText = "";
            int counter = 1;
            int padding = stoi(key.substr(key.size()-1, 1));

            for(int i=0; i<cipherText.size()/permutationKeyLen; i++)
            {
                for(int j = 0; j<permutationKeyLen; j++)
                {
                    section += cipherText[permutationKeyLen*i +j];
                }
                for(int j = 0; j<permutationKeyLen; j++)
                {
                    for(int k = 0; k<permutationKeyLen; k++)
                    {
                        if(permutationKey[k] == counter)
                        {
                            ogText += section[k];
                            counter++;
                            break;
                        }
                    }
                }
                counter = 1;
                plainText += ogText;
                ogText = "";
                section = "";
            }
            plainText = plainText.substr(0, plainText.size()-padding);
        };

        permutation();
        viginere();
        railFence();
    };
    decrypt();
    if(option == 0)
    {
        cout<<endl<<"PLAINTEXT: \n\n"<<plainText;
    }
    else if (option ==1)
    {
        ofstream output("output.txt");
        if(!output)
        {
            cerr<<endl<<endl<<"COULD NOT OPEN \"output.txt\"."<<endl<<endl;
            return;
        }
        else
        {
            cout<<endl<<endl<<"PLAINTEXT IS IN \"output.txt\"."<<endl;
            output<<plainText;
        }
    }
    else if(option == 2)
    {
        ofstream output(file, ios::binary);
        if(!output)
        {
            cerr<<endl<<endl<<"COULD NOT OPEN \""<<file<<"\"."<<endl<<endl;
            return;
        }
        else
        {
            cout<<endl<<endl<<"PLAINTEXT IS IN \""<<file<<"\"."<<endl;
            output.write(plainText.data(), plainText.size());
        }
    }
    getline(cin, ignore);
}

int main()
{
    char option;
    string ignore;
    string key = "";
    string plainText = "";
    string cipherText = "";

    auto eraseInputOutputTXT = []()
    {
        ofstream output("output.txt");
        if(!output)
        {
            cerr<<endl<<endl<<"COULD NOT OPEN \"output.txt\". MANUAL CLEANUP REQUIRED."<<endl<<endl;
            exit(0);
        }
        else
        {
            output<<"";
        }
        ofstream input("input.txt");
        if(!input)
        {
            cerr<<endl<<endl<<"COULD NOT OPEN \"intput.txt\". MANUAL CLEANUP REQUIRED."<<endl<<endl;
            exit(0);
        }
        else
        {
            input<<"";
        }
    };

    while(true)
    {
        cout<<"PLEASE NOTE:"<<endl<<endl<<"[1] PLEASE PRESERVE THE OUTER QUOTE MARKS THAT THE PROGRAM ADDS IN ENCRYPTION, OTHERWISE THE CIPHERTEXT WILL NOT DECRYPT PROPERLY. THIS APPLIES FOR NORMAL AND TXT- ENCRYPTING.\n\n[2] WHEN FEEDING CIPHERTEXT TO THE DECRYPTOR, MAKE SURE THAT THERE ARE OUTER QUOTE MARKS (ADD IF THERE ARE NONE), BECAUSE THEY ARE ESSENTIAL FOR THE DECRYPTOR'S INTENDED FUNCTION. THIS APPLIES FOR NORMAL AND TXT- DECRYPTING.\n\n[3] FOR LONG INPUTS OR INPUTS WITH NEWLINES, PLEASE USE THE TXT VERSIONS OF THE ENCRYPTOR/DECRYPTOR AND EDIT THE APPROPIATE FILES.\n\n[4] PLEASE USE THE PROVIDED OPTION TO QUIT RATHER THAN THE KEYBOARD INTERRUPTS OR CLOSING THE TAB.\n\n[5] ASCII CHARACTERS ONLY PLEASE.\n\n[6] \"input.txt\" AND \"ouput.txt\" ARE ERASED WHEN THE PROGRAM QUITS OR THE USER LOGS OUT.\n\n[7] IN TXT VERSIONS, WRITE TO FILES BEFORE CHOOSING MENU OPTION."<<endl<<endl;
        getline(cin, ignore);
        while(true)
        {
            key = "";
            plainText = "";
            cipherText = "";
            cls();
            cout<<"\n[1] ENCRYPT \n[2] DECRYPT \n[3] TXT-ENCRYPT \n[4] TXT-DECRYPT \n[5] FILE-ENCRYPT \n[6] FILE-DECRYPT \n[L] LOGOUT \n[Q] QUIT"<<endl<<endl;
            cin>>option;
            cin.ignore(256, '\n');
            cls();
            cout<<endl<<endl;
            if(toupper(option) == 'Q')
            {
                eraseInputOutputTXT();
                return 0;
            }
            else if(toupper(option) == 'L')
            {
                eraseInputOutputTXT();
                break;
            }
            else if(isalpha(option))
            {
                continue;
            }
            switch(stoi(string(1, option)))
            {
                case 1:
                    encrypt(0, key, plainText, cipherText);
                break;

                case 2:
                    decrypt(0, key, plainText, cipherText);
                break;

                case 3:
                    encrypt(1, key, plainText, cipherText);
                    cout<<endl<<"PRESS ENTER TO ERASE \"input.txt\" AND \"ouput.txt\"."<<endl;
                    getline(cin, ignore);
                    eraseInputOutputTXT();
                break;

                case 4:
                    decrypt(1, key, plainText, cipherText);
                    cout<<endl<<"PRESS ENTER TO ERASE \"input.txt\" AND \"ouput.txt\"."<<endl;
                    getline(cin, ignore);
                    eraseInputOutputTXT();
                break;

                case 5:
                    encrypt(2, key, plainText, cipherText);
                    cout<<endl<<"PLEASE COPY THE ENCRYPTION KEY BEFORE PRESSING ENTER."<<endl;
                    getline(cin, ignore);
                break;

                case 6:
                    decrypt(2, key, plainText, cipherText);
                    cout<<endl<<"PLEASE COPY THE ENCRYPTION KEY BEFORE PRESSING ENTER."<<endl;
                    getline(cin, ignore);
                break;
            }
        }
    }
}
